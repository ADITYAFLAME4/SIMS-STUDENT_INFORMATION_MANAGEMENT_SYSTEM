
	<?php

$host ="localhost";
$uname = "root";
$pwd = "";
$db_name = "studentmanagement";

    ?>
