package com.example.studentinformationsystem;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ViewFlipper;

import androidx.fragment.app.Fragment;


public class DashboardFragment extends Fragment {

    TextView txtMarquee;


Button button1;
    Button button2;
    Button button3;
    Button button4;

ViewFlipper flipper;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.dashboardfragment, null);
        txtMarquee = (TextView) root.findViewById(R.id.marqueeText);
        txtMarquee.setSelected(true);

        button1 = root.findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://makaut1.ucanapply.com/smartexam/public/result-details");
            }
        });
        button2 = root.findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://technoindiagroup.com/");
            }
        });
        button3 = root.findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("http://makautexam.net/routine.html");
            }
        });
        button4 = root.findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://nptel.ac.in/");
            }
        });






        return root;

    }
    private void gotoUrl(String s){
    Uri uri = Uri.parse(s);
    startActivity(new Intent(Intent.ACTION_VIEW,uri));}
}




